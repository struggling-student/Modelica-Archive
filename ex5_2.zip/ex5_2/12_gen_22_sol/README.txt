
Nelle soluzioni proposte si è sempre usato:  MyMagicNumber = 0.
 
