#!/bin/sh


rm *~


rm *.o

rm System*.c

rm *.libs

rm *.log

rm *.makefile

rm *.h

rm *.json

rm *.xml

rm System_res.mat

