
Nelle soluzioni proposte si è sempre usato:  MyMagicNumber = 0.
 
Il testo dell'esame chiede un orizzonte di simulazione di 1E4.

Per vedere l'andamento del valor medio è però utile scegliere un orizzonte di simulazione di 1E7.

Ovviamente una soluzione con orizzone di simulazione 1E4 è da considerarsi corretta.

un azienda ha un ciclo di sviluppo software con 6 fasi

qui abbiamo i tempi attesi (in giorni) per il completamento 
fase1 = 180 + number
fase 2= ..


fase 6= 1 giorno
10000 giorni orizzonte di simulazione

abbiamo la matrice delle probabilità

p_i,i = probabilià di rimanere nello stato i
è tau(i) = 1 / 1 - p_i,i

tempo atteso di soggiorno nello stato i(tempo atteso di completamento della fase i) è T * tau(i)

monitor calcola valore atteso del tempo di completamento

complemention time -> non ho deviazione standard--> il tempo medio è time / numero di delivery


in P.mo si usa anche Phase che è il tempo atteso di completamento delle fasi
