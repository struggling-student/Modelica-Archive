#!/bin/sh

./mkload.sh

omc +std=3.3 run.mos
